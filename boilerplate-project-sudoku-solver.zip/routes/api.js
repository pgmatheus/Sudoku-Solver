'use strict';


const SudokuSolver = require('../controllers/sudoku-solver.js');

module.exports = function (app) {
  
  let solver = new SudokuSolver();

  app.route('/api/check')
    .post((req, res) => {
      let input = req.body;
      if (solver.validate(input) != true){
        res.json(solver.validate(input))
      }
      else if (input.coordinate != undefined || input.value != undefined){
        let checkc = checkarr(input.coordinate);
        let checkv = input.value.match(/^[1-9]$/);
        if (checkc == null){
          res.json({ "error": "Invalid coordinate" })
        }
        else if (checkv == null){
          res.json({ "error": "Invalid value" })
        }
        else{
          let r = retv(input.coordinate);
          let c = parseInt(input.coordinate.match(/[1-9]$/))-1;
          let matr = getarraymatrix(input.puzzle);
          matr[r][c] = 0;
          let rpl = solver.checkRowPlacement(matr, r, c, input.value);
          let cpl = solver.checkColPlacement(matr, r, c, input.value);
          let apl = solver.checkRegionPlacement(matr, r, c, input.value);
          let conflict = [];
          if (!rpl) {conflict.push('row')};
          if (!cpl) {conflict.push('column')};     
          if (!apl) {conflict.push('region')};        
          if (!rpl || !cpl || !apl){
            res.json({ "valid": false, "conflict": conflict})      
          }
          else (
            res.json({ "valid": true})
          )





        }
      }
      else{
        res.json({ error: 'Required field(s) missing' })
      }
      


      
    });
    
  app.route('/api/solve')
    .post((req, res) => {
      let input = req.body;


      if (solver.validate(input) != true){
        res.json(solver.validate(input))
      }
      else{
        let inputm = getarraymatrix(input.puzzle);
        let z = solver.solve(inputm);
        if (z != false){
          res.json({solution: tostr(z)})
        
        }
        else{
          res.json({error: 'Puzzle cannot be solved' })
        }


      }

         







    });


function tostr(matrix){
  return matrix.flat().join("");
}

function getarraymatrix(puzzleString){
    let matrix = []
    let cont = 0;
    for (let i = 0;i<9; i++){
        matrix[i] = []
        for (let j = 0;j<9;j++){
          if (puzzleString.charAt(cont) == '.'){
            matrix[i][j] = 0
          }
          else{
            matrix[i][j] = parseInt(puzzleString.charAt(cont))
           }
            cont++;
        }        
    }
    return matrix
}

function checkarr(string){
  let regex = /^[a-i][1-9]$/i
  let z = string.match(regex)
  return z
}

function retv (string) {
  let z = string.toUpperCase().match(/^[A-I]/);

    switch (String(z)) {
    case 'A':
      return 0
      break;
    case 'B':
     return 1
     break;
    case 'C':
      return 2
      break;
    case 'D':
      return 3
      break;
    case 'E':
     return 4
     break;
    case 'F':
     return 5
     break;
    case 'G':
     return 6
     break;
    case 'H':
      return 7
     break;
    case 'I':
     return 8
     break;
    default:
    return 'que'
  }

}




};





 