class SudokuSolver {

  validate(string) {
      let regex = /^[0-9/./]+$/ 
  if (string == undefined || string.puzzle == undefined){
        return {error: 'Required field missing' }
      }
      if (string.puzzle.match(regex) == null){

        return { error: 'Invalid characters in puzzle' }
      }
      else if(string.puzzle.length != 81){
        return { error: 'Expected puzzle to be 81 characters long' }  
      }
      else {return true}

  }

  checkRowPlacement(matrix, row, column, value) {
    for (let i = 0; i < 9; i++) {
        if (matrix[row][i] == value) { return false }
    }
    return true  
  }

  checkColPlacement(matrix, row, column, value) {
    for (let i = 0; i < 9; i++) {
        if (matrix[i][column] == value) { return false }
    }
    return true
  }

  checkRegionPlacement(matrix, row, column, value) {
    let subrowcol = [Math.ceil((1 + row) / 3), Math.ceil((1 + column) / 3)];
    for (let i = (subrowcol[0] - 1) * 3; i < 3 * (subrowcol[0] - 1) + 3; i++) {
        for (let j = (subrowcol[1] - 1) * 3; j < 3 * (subrowcol[1] - 1) + 3; j++) {
            if (matrix[i][j] == value) { return false }
        }
    }
    return true
  }

  solve(board) {
    {
    let row = -1;
    let col = -1;
    let isEmpty = true;


    for(let i = 0; i < 9; i++)
    {
        for(let j = 0; j < 9; j++)
        {
            if (board[i][j] == 0)
            {
                row = i;
                col = j;
                isEmpty = false;
                break;
            }
        }
        if (!isEmpty)
        {
            break;
        }
    }
 
     if (isEmpty)
    {
        return true;
    }
 
    for(let num = 1; num <= 9; num++)
    {
      let a = this.checkRowPlacement(board, row, col, num);
      let b = this.checkColPlacement(board, row, col, num);
      let c = this.checkRegionPlacement(board, row, col, num);
        if (a && b && c)
        {
            board[row][col] = num;
            let s = this.solve(board)
            if (s)
            {
                return board;
            }
            else
            {
                board[row][col] = 0;
            }
        }
    }
    return false;
  }
  }
}

  
module.exports = SudokuSolver;

